start Lain.exe --respath live2d.chara
start Lain.exe --respath sound.scenario.bgm
start Lain.exe --respath bg
start Lain.exe --respath comic.comic_singleframe
start Lain.exe --respath comic.comic_fourframe